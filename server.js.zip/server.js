import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const clamp = (n, lo = 0, hi = Infinity) => Math.max(lo, Math.min(hi, n));
const pct = (val, max) => Math.round((Math.max(0, Math.min(val, max)) / max) * 100);
const rankPoints10 = (i) => [10,9,8,7,6,5,4,3,2,1][i] ?? 0;
const rankPoints5  = (i) => [10,8,6,4,2][i] ?? 0;
const escapeRegExp = (s) => (s || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const containsAny = (txt, words) => words.some(w => new RegExp(`\\b${escapeRegExp(w)}\\b`, "i").test(txt || ""));

const MAX = { CUL: 40, AUT: 34, PLN: 38, SOC: 30, ADV: 44, LUX: 40, COM: 40 };

const RECS = {
  CulturalExplorer: {
    whoYouAre:"You’re driven by deep curiosity about the world’s cultures—every destination becomes a living classroom.",
    motivation:"Learning and authentic cultural immersion.",
    idealFeeling:"“I understand this place and its people so much better now.”",
    energizes:"Meaningful conversations with locals, hidden historical gems, and experiencing traditions firsthand.",
    destinations:["Japan (tea ceremonies, temple stays)","Peru (Inca heritage)","Egypt (archaeological sites)","India (spiritual traditions)","Morocco (Berber culture)"],
    activities:["Private museum tours with experts","Traditional cooking classes","Historical walking tours","Local festivals","Artisan workshops"],
    lodging:["Boutique hotels with local character","Traditional ryokans/riads","Small-scale guesthouses"]
  },
  MeticulousPlanner: {
    whoYouAre:"You thrive on structure and clarity—well-researched itineraries let you do more with less stress.",
    motivation:"Efficiency, reliability, and maximizing limited time.",
    idealFeeling:"“Everything ran like clockwork and I still had time to enjoy it.”",
    energizes:"Clear timetables, optimized routes, skip-the-line entries, and organized day plans.",
    destinations:["Switzerland","Singapore","Scandinavia","UK","Canada"],
    activities:["Pre-booked highlights","Timed-entry museums","Rail passes","Guided day trips"],
    lodging:["Business-class hotels","Reliable chains with high cleanliness","Apart-hotels near transit"]
  },
  SpontaneousAdventurer: {
    whoYouAre:"You’re energized by freedom and novelty—detours and serendipity make your best stories.",
    motivation:"Discovery, challenge, and flexibility.",
    idealFeeling:"“We followed our curiosity and found something incredible.”",
    energizes:"Open schedules, outdoor experiences, street food, and local tips.",
    destinations:["New Zealand","Costa Rica","Vietnam","Iceland","South Africa"],
    activities:["Hikes & treks","Waterfalls / hot springs","Food markets","Scooter or bike days","Last-minute tours"],
    lodging:["Cool hostels","Cabins","Unique Airbnb stays"]
  },
  LuxurySeeker: {
    whoYouAre:"Travel is your time to indulge—comfort, design, and premium service elevate every moment.",
    motivation:"Relaxation and curated, high-touch experiences.",
    idealFeeling:"“Effortless, exclusive, and unforgettable.”",
    energizes:"Fine dining, signature suites, private guides, and seamless transfers.",
    destinations:["Maldives","Dubai","Monaco","St. Barts","Amalfi Coast"],
    activities:["Private yacht days","Chef’s tables","Helicopter tours","Spa rituals"],
    lodging:["5★ resorts","Design-forward boutique hotels","Villas with staff"]
  },
  SocialConnector: {
    whoYouAre:"You travel for people—shared experiences and new friends make places come alive.",
    motivation:"Community, connection, and memorable nights.",
    idealFeeling:"“We met amazing people and made stories together.”",
    energizes:"Group tours, festivals, cooking classes, and nightlife.",
    destinations:["Barcelona","Mexico City","Bangkok","Lisbon","Medellín"],
    activities:["Food crawls","Dance classes","Group hikes","Festival trips"],
    lodging:["Social hostels","Co-living hotels","Riad courtyards & rooftops"]
  },
  ComfortTraveler: {
    whoYouAre:"You like trips that feel easy and restorative—familiar amenities and low-friction plans matter.",
    motivation:"Comfort, safety, and stress-free downtime.",
    idealFeeling:"“I’m relaxed, recharged, and never rushed.”",
    energizes:"Walkable areas, comfy beds, simple logistics, and great pools.",
    destinations:["Hawaii","Portugal","Vancouver","Ireland","The Carolinas"],
    activities:["Scenic drives","Spa days","Gentle walking tours","Beach & brunch"],
    lodging:["Reliable chains","Resorts with amenities","Quiet apartments"]
  }
};

function scoreAssessment(answers = {}) {
  const SUBS = { CUL:0, AUT:0, PLN:0, SOC:0, ADV:0, LUX:0, COM:0 };
  const add = (k, v) => (SUBS[k] = Math.max(0, SUBS[k] + (v || 0)));

  if (Number.isFinite(answers.Q3)) {
    const s = clamp(Number(answers.Q3), 1, 10) - 1;
    const ten = s * (10 / 9);
    add("AUT", ten); add("CUL", 0.4 * ten);
  }

  switch ((answers.Q4 || "").toLowerCase()) {
    case "mostly planned": add("PLN",10); break;
    case "balanced": add("PLN",5); add("ADV",5); break;
    case "mostly spontaneous": add("ADV",10); break;
  }

  const mapFreq = (s) => {
    const v = (s || "").toLowerCase();
    if (["always","very often","often"].some(w=>v.includes(w))) return 10;
    if (["sometimes"].some(w=>v.includes(w))) return 5;
    if (["rarely","never"].some(w=>v.includes(w))) return 0;
    return 0;
  };
  if (answers.Q5) add("CUL", mapFreq(answers.Q5));

  if (Number.isFinite(answers.Q6)) add("PLN", clamp(Number(answers.Q6),0,10));

  switch ((answers.Q7 || "").toLowerCase()) {
    case "long weekend":
    case "long weekend (3-4 days)": add("COM",8); break;
    case "one week": add("PLN",6); add("COM",2); break;
    case "two weeks": add("CUL",6); add("ADV",4); break;
    case "one month": add("CUL",6); add("ADV",6); break;
    case "longer than a month":
    case "> one month": add("ADV",8); add("CUL",6); break;
    case "varies":
    case "varies by destination": add("PLN",4); add("ADV",4); break;
  }

  const q8 = Array.isArray(answers.Q8) ? answers.Q8 : [];
  let q8CUL = 0;
  for (const sel of q8) {
    const s = (sel || "").toLowerCase();
    if (s.includes("documentaries")) q8CUL += 2;
    else if (s.includes("guidebooks")) { q8CUL += 2; add("PLN",1); }
    else if (s.includes("social") || s.includes("blogs")) { q8CUL += 1; add("ADV",1); }
    else if (s.includes("learn basic language")) { q8CUL += 2; add("AUT",1); }
    else if (s.includes("historical") || s.includes("study")) q8CUL += 3;
    else if (s.includes("connect with locals")) { add("SOC",2); add("AUT",1); }
    else if (s.includes("not interested")) q8CUL = 0;
  }
  add("CUL", Math.min(q8CUL, 10));

  switch ((answers.Q9 || "").toLowerCase()) {
    case "avoid countries that don't speak english/stick to tourist areas":
    case "avoid countries that don't speak english":
    case "stick to tourist areas": add("COM",6); add("PLN",2); break;
    case "learn basic phrases beforehand": add("CUL",3); add("AUT",3); break;
    case "rely on translation apps and gestures": add("ADV",3); add("AUT",2); break;
    case "see it as part of the adventure": add("ADV",6); add("AUT",2); break;
    case "always travel with guides/translators": add("LUX",3); add("COM",3); add("PLN",2); break;
  }

  switch ((answers.Q10 || "").toLowerCase()) {
    case "you are actively engaging and learning as much as possible about the culture":
      add("CUL",4); add("SOC",3); add("AUT",3); break;
    case "you are just quietly observing and or asking questions":
      add("CUL",3); add("AUT",2); break;
    case "try to avoid cultural practices if possible":
      add("COM",5); break;
  }

  const q11 = Array.isArray(answers.Q11) ? answers.Q11 : [];
  const q11Cap = { CUL:0, SOC:0, ADV:0, LUX:0, COM:0 };
  q11.forEach((label, idx) => {
    const pts = rankPoints10(idx);
    switch (label) {
      case "Capturing beautiful moments/photography": q11Cap.ADV += Math.min(2, pts); q11Cap.LUX += Math.min(1, pts); break;
      case "Familiar amenities and comfortable accomadations": q11Cap.COM += pts; break;
      case "Personal growth and self-discovery": q11Cap.ADV += pts; break;
      case "Learning about history and culture": q11Cap.CUL += pts; break;
      case "Connecting with local people": q11Cap.SOC += pts; break;
      case "Beautiful scenery and landscapes": q11Cap.ADV += pts; break;
      case "Activity and adventure": q11Cap.ADV += pts; break;
      case "Culinary experiences": if (idx <= 2) add("AUT",5); else add("AUT",2); break;
      case "Pure relaxation and escape": q11Cap.COM += pts; break;
      case "Luxury and premium services": q11Cap.LUX += pts; break;
    }
  });
  add("CUL", Math.min(q11Cap.CUL, 12));
  add("SOC", Math.min(q11Cap.SOC, 12));
  add("ADV", Math.min(q11Cap.ADV, 12));
  add("LUX", Math.min(q11Cap.LUX, 12));
  add("COM", Math.min(q11Cap.COM, 12));

  const q12 = (answers.Q12 || "").toString();
  if (containsAny(q12, ["culture","history","locals","people"])) { add("CUL",4); add("SOC",2); }
  if (containsAny(q12, ["food","restaurant","cuisine"])) add("AUT",3);
  if (containsAny(q12, ["scenery","landscape","hike","activity"])) add("ADV",3);
  if (containsAny(q12, ["hotel","comfort","amenities"])) { add("COM",3); add("LUX",2); }

  switch ((answers.Q13 || "").toLowerCase()) {
    case "relaxing": add("COM",6); break;
    case "exploring": add("ADV",6); break;
    case "social events": add("SOC",6); break;
    case "hobbies": add("PLN",3); break;
    case "working": add("PLN",4); break;
  }

  switch ((answers.Q14 || "").toLowerCase()) {
    case "promoter": add("SOC",8); break;
    case "passive": add("SOC",4); break;
    case "detractor": add("SOC",1); break;
  }

  const q15 = Array.isArray(answers.Q15) ? answers.Q15 : [];
  for (const sel of q15) {
    switch (sel) {
      case "Extensive online review research": add("PLN",4); break;
      case "Ask friends/locals for recommendations": add("SOC",3); add("AUT",2); break;
      case "Walk by and decide based on atmosphere": add("ADV",3); break;
      case "Choose the busiest/most popular option": add("COM",2); break;
      case "Seek out the most unique/unusual option": add("ADV",4); add("AUT",2); break;
      case "Stick with cuisines I know I like": add("COM",4); break;
    }
  }

  switch ((answers.Q16 || "").toLowerCase()) {
    case "promoter": add("COM",6); break;
    case "passive": add("COM",3); break;
    case "detractor": add("ADV",3); break;
  }

  switch ((answers.Q17 || "").toLowerCase()) {
    case "i plan most things": add("PLN",6); break;
    case "we decide together": add("SOC",4); add("PLN",2); break;
    case "i follow others lead": add("SOC",3); add("COM",2); break;
  }

  switch ((answers.Q18 || "").toLowerCase()) {
    case "get stressed": add("COM",4); add("PLN",2); break;
    case "see it as an opportunity for something new": add("ADV",6); break;
    case "find a quick backup": add("PLN",5); add("ADV",3); break;
  }

  switch ((answers.Q19 || "").toLowerCase()) {
    case "promoter": add("ADV",6); break;
    case "passive": add("ADV",3); break;
    case "detractor": add("COM",4); break;
  }

  switch ((answers.Q20 || "").toLowerCase()) {
    case "2+ hours": add("COM",4); break;
    case "6+ hours": add("PLN",2); add("COM",2); break;
    case "8+ hours": add("ADV",3); break;
    case "12+ hours": add("ADV",5); break;
    case "no flight is too long": add("ADV",7); break;
  }

  const q21 = Array.isArray(answers.Q21) ? answers.Q21 : [];
  for (const sel of q21) {
    switch (sel) {
      case "Pack light - only essentials": add("ADV",3); break;
      case "Pack for every possible scenario": add("PLN",4); add("COM",2); break;
      case "Follow detailed packing lists": add("PLN",5); break;
      case "Pack quickly at the last minute": add("ADV",3); add("PLN",-2); break;
      case "Prioritize comfort items": add("COM",4); break;
      case "Pack for style and photos": add("LUX",4); break;
    }
  }

  const q22 = Array.isArray(answers.Q22) ? answers.Q22 : [];
  let aut22=0, lux22=0, com22=0, soc22=0;
  q22.forEach((label, idx) => {
    const pts = rankPoints10(idx);
    switch (label) {
      case "Prime location/walkability": aut22 += pts; break;
      case "Reliable comfort and cleanliness": com22 += pts; break;
      case "Authentic local experience": aut22 += pts + (idx<=2?2:0); break;
      case "Best value for money": if (idx<=2) com22 += 4; break;
      case "Privacy and quiet": com22 += pts; break;
      case "Luxury amenities and service": lux22 += pts + (idx<=2?2:0); break;
      case "Unique/Instagram-worthy properties": lux22 += idx<=2?6:2; break;
      case "Meeting other travelers": soc22 += pts; break;
    }
  });
  SUBS.AUT += Math.min(aut22, 20);
  SUBS.LUX += Math.min(lux22, 20);
  SUBS.COM += Math.min(com22, 20);
  SUBS.SOC += Math.min(soc22, 10);

  switch ((answers.Q23 || "").toLowerCase()) {
    case "disappointed": SUBS.PLN += 5; break;
    case "fine as long as key highlights are done": SUBS.PLN += 3; SUBS.ADV += 2; break;
    case "totally fine": SUBS.ADV += 5; break;
  }

  switch ((answers.Q24 || "").toLowerCase()) {
    case "morning": SUBS.PLN += 2; break;
    case "afternoon": SUBS.ADV += 2; break;
    case "evening": SUBS.SOC += 3; break;
    case "night": SUBS.SOC += 4; SUBS.ADV += 2; break;
    case "other": SUBS.PLN += 1; SUBS.ADV += 1; break;
  }

  switch ((answers.Q25 || "").toLowerCase()) {
    case "i stick to a strict budget": SUBS.COM += 5; break;
    case "i splurge on special experiences": SUBS.LUX += 5; SUBS.AUT += 2; break;
    case "i mix budget options with occasional luxury": SUBS.LUX += 3; SUBS.COM += 3; break;
    case "i don’t track spending closely": SUBS.ADV += 3; SUBS.LUX += 3; break;
  }

  const q26 = Array.isArray(answers.Q26) ? answers.Q26 : [];
  q26.forEach((label, idx) => {
    const pts = rankPoints5(idx);
    switch (label) {
      case "Accommodation / Comfort": SUBS.LUX += pts; SUBS.COM += Math.round(pts/2); break;
      case "Food & Dining": SUBS.AUT += pts; break;
      case "Activities & Experiences": SUBS.ADV += pts; break;
      case "Shopping & Souvenirs": SUBS.LUX += Math.round(pts/2); break;
      case "Transportation Upgrades (business class, private cars, etc.)": SUBS.LUX += pts; break;
    }
  });

  const PCT = Object.fromEntries(Object.entries(SUBS).map(([k,v]) => [k, pct(v, MAX[k])]));

  const CE = 0.4*PCT.CUL + 0.25*PCT.AUT + 0.2*PCT.PLN + 0.1*PCT.SOC + 0.05*PCT.ADV;
  const MP = 0.5*PCT.PLN + 0.15*PCT.CUL + 0.1*PCT.AUT + 0.1*PCT.COM + 0.1*PCT.SOC + 0.05*PCT.ADV;
  const SAraw = 0.55*PCT.ADV + 0.15*PCT.AUT + 0.1*PCT.SOC + 0.1*PCT.CUL + 0.1*PCT.PLN;
  const SA = SAraw * (1 - Math.max(0, (PCT.PLN - 70) / 120));
  const LS = 0.6*PCT.LUX + 0.2*PCT.COM + 0.1*PCT.PLN + 0.1*PCT.ADV;
  const SC = 0.6*PCT.SOC + 0.15*PCT.ADV + 0.15*PCT.AUT + 0.1*PCT.CUL;
  const CT = 0.55*PCT.COM + 0.2*PCT.PLN + 0.15*PCT.LUX + 0.1*PCT.ADV;

  const types = {
    CulturalExplorer: Math.round(CE),
    MeticulousPlanner: Math.round(MP),
    SpontaneousAdventurer: Math.round(SA),
    LuxurySeeker: Math.round(LS),
    SocialConnector: Math.round(SC),
    ComfortTraveler: Math.round(CT)
  };
  const primaryKey = Object.entries(types).sort((a,b)=>b[1]-a[1])[0][0];

  const sortedSubs = Object.entries(PCT).sort((a,b)=>b[1]-a[1]);
  const reasonMap = { CUL:"High Cultural Interest", AUT:"Authenticity Focus", PLN:"Planning Approach", SOC:"Social Orientation", ADV:"Adventure Openness", LUX:"Luxury Preference", COM:"Comfort Preference" };
  const reasonText = {
    CUL:"You actively seek to understand local customs, history, and traditions.",
    AUT:"You prefer genuine experiences over tourist-structured activities.",
    PLN:"You research and structure your days to maximize what matters to you.",
    SOC:"You enjoy human connection and shared experiences while traveling.",
    ADV:"You embrace flexibility, novelty, and lightly structured days.",
    LUX:"Premium service and elevated comfort enhance your trips.",
    COM:"Reliability, ease, and low-stress logistics are important to you."
  };
  const reasons = sortedSubs.slice(0,4).map(([k,v]) => `${reasonMap[k]} (${v}%): ${reasonText[k]}`);

  const RECS_BY_KEY = {
    CulturalExplorer: RECS.CulturalExplorer,
    MeticulousPlanner: RECS.MeticulousPlanner,
    SpontaneousAdventurer: RECS.SpontaneousAdventurer,
    LuxurySeeker: RECS.LuxurySeeker,
    SocialConnector: RECS.SocialConnector,
    ComfortTraveler: RECS.ComfortTraveler
  };

  return {
    subscores: PCT,
    types,
    primary: primaryKey,
    reasons,
    recommendations: RECS_BY_KEY[primaryKey] || RECS.CulturalExplorer
  };
}

app.get("/", (_req, res) => res.json({ ok:true, message:"Travel Personality API is healthy. POST /score with {answers} to get a report." }));

app.post("/score", (req, res) => {
  try {
    const { answers } = req.body || {};
    const result = scoreAssessment(answers || {});
    res.json({ ok:true, ...result });
  } catch (e) {
    console.error(e);
    res.status(400).json({ ok:false, error:"Invalid input", details:String(e) });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`✅ Travel Personality API running on http://localhost:${PORT}`));
